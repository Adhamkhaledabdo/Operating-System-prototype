import java.io.Serializable;

public enum ProcessState{
    Blocked,Running,New,Ready,Finished;
	
	
	
	
}
