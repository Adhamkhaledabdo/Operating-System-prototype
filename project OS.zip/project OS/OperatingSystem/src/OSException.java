public class OSException extends Exception {

    public OSException() {
    }

    public OSException(String message) {
        super(message);
    }
    
}
